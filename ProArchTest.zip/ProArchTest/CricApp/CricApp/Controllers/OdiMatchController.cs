﻿using CricApp.Model;
using CricApp.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CricApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OdiMatchController : ControllerBase
    {
        private static IMatchService _matchService;

        public OdiMatchController(IMatchService matchService)
        {
            _matchService = matchService;

        }

        [HttpGet]
        public MatchDetails GetMatchDetails()
        {
            return _matchService.MatchRecords();
        }

        //
        [HttpGet]
        public Dictionary<string,int> GetPlayerRecord(int playerId)
        {
            return _matchService.PlayerRecord(playerId);
        }
    }
}

﻿using CricApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CricApp.Service
{
    public interface IMatchService
    {
        public MatchDetails MatchRecords();
        public Dictionary<string, int> PlayerRecord(int playerId);
    }
}

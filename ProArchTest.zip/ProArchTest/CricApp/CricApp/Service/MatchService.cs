﻿using CricApp.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CricApp.Service
{
    public class MatchService : IMatchService
    {
        public MatchDetails MatchRecords()
        {
            var md = new MatchDetails();
            string path = @"C:\Users\user\Desktop\ProArchTest\CricApp\CricApp\Data\64862.csv";

            string[] lines = System.IO.File.ReadAllLines(path);
            foreach (string line in lines)
            {
                string[] columns = line.Split(',');
                foreach (string column in columns)
                {
                    // Do something to read the data in the file
                }
            }
            return md;
        }

        public Dictionary<string, int> PlayerRecord(int playerId)
        {
           return PlayersRecords(playerId);
        }

        private Dictionary<string, int> PlayersRecords(int playerId)
        {
            var p1 = new PlayerStats();
            p1.PlayerId = 1;

            var pRecord1 = new Dictionary<string, int>();
            var playersRecords = new List<PlayerStats>();

            pRecord1.Add("Player Id", 1);
            pRecord1.Add("Total Runs Scored", 133);
            pRecord1.Add("Dots", 13);
            pRecord1.Add("Ones", 45);
            pRecord1.Add("Twos", 12);
            pRecord1.Add("Three", 2);
            pRecord1.Add("Fours", 3);
            pRecord1.Add("Sixes", 2);
            var ballPlayed = pRecord1.Skip(1).Sum(x => x.Value);
            pRecord1.Add("Balls Played", ballPlayed);
            p1.PlayerRecords = pRecord1;
            playersRecords.Add(p1);

            var p2 = new PlayerStats();
            p2.PlayerId = 2;
            var pRecord2 = new Dictionary<string, int>();
            pRecord2.Add("Player Id", 2);
            pRecord2.Add("Total Runs Scored", 123);
            pRecord2.Add("Dots", 13);
            pRecord2.Add("Ones", 45);
            pRecord2.Add("Twos", 11);
            pRecord2.Add("Three", 2);
            pRecord2.Add("Fours", 3);
            pRecord2.Add("Sixes", 2);
            var ballPlayed2 = pRecord2.Skip(1).Sum(x => x.Value);
            pRecord2.Add("Total Runs Scored", ballPlayed2);
            p2.PlayerRecords = pRecord2;
            playersRecords.Add(p2);

            var retPlayer = playersRecords.FirstOrDefault(x => x.PlayerId == playerId).PlayerRecords;
            return (Dictionary<string, int>)retPlayer;
        }

        private class PlayerStats
        {
            public int PlayerId { get; set; }
            public IDictionary<string, int> PlayerRecords { get; set; }
        }
    }
}
